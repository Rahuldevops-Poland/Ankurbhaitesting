import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

import java.util.List;

public class Learning {

    @Test
    public void posts()
    {
        RestAssured.baseURI = "http://localhost:3000/";
        RequestSpecification httpRequest = RestAssured.given();
        Response response = httpRequest.get("/posts");
        JsonPath jsonPathEvaluator = response.jsonPath();
        System.out.println("staus code:"+response.statusCode());
        if(response.statusCode()==200) {
            // Let us check completion status for 3rd parameter
            System.out.println("body received from Response " + jsonPathEvaluator.getString("[0].body"));
            System.out.println("body received from Response " + jsonPathEvaluator.getString("[0].body"));

            //to print value based on condition find its body value where title is something
            List<String>body=    jsonPathEvaluator.getList("findAll{it.title=='qui est esse'}.body");
            System.out.println(body);

            //to find specific single records where title is this and id is this
          String result=  jsonPathEvaluator.getString("find{it.title=='eum et est occaecati'& it.id==4}.body");
System.out.println("result is: "+result);

            //to find list of records where title is this or id is this

            List<String> result1=  jsonPathEvaluator.getList("findAll{it.id==1|it.id==2|it.id==3|it.id==4}");
            System.out.println("result1 is: "+result1);
            System.out.println(" ");

            //to print records with range
            List<String> result2 = jsonPathEvaluator.getList("findAll{it.id>=20 & it.id<=256}");
            System.out.println("result1 is: " + result1);



            //to print all body
            List<String> title=jsonPathEvaluator.getList("title");
            for (int i=0;i<=10;i++) {
                System.out.println("all title: " + title.get(i));
            }
        }
    }

}
