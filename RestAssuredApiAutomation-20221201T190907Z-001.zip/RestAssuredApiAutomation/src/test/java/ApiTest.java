import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class ApiTest {


    @Test
    void testing()
    {
       Response response= RestAssured.get("https://reqres.in/api/users?page=2");

        System.out.println("response is: "+ response.asString());
        int status_code=response.getStatusCode();
       System.out.println("status code is: "+status_code);
        System.out.println("body is: "+response.getBody().asString());
        Assert.assertEquals(status_code,200);
    }
@Test
    void test2(){
    given().get("https://reqres.in/api/users?page=2").
    then().statusCode(200);
}

    @Test
    void test3(){
        baseURI="https://reqres.in/api";
        given().get("https://reqres.in/api/users?page=2").
                then().statusCode(200);
    }
    @Test
    void test4(){

        baseURI="https://reqres.in/api";
        given().get("/users?page=2").
                then().statusCode(200)
                .body("data[1].id",equalTo(8)).log().all();   //to print logs

    }
}
