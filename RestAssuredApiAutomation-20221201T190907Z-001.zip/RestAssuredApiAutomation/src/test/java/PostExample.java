import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class PostExample {
public static void main(String arg[])
{
    RestAssured.given()
            .log().all()
            .baseUri("http://localhost:3000/")
            .basePath("comments")
            .body("  {\n" +
                    "    \"postId\": 1,\n" +
                    "    \"id\": 505,\n" +
                    "    \"name\": \"id ankurlabore ex et quam laborum\",\n" +
                    "    \"email\": \"ankurEliseo@gardner.biz\",\n" +
                    "    \"body\": \"ankurlaudantium enim quasi est quidem magnam voluptate ipsam eos\\ntempora quo necessitatibus\\ndolor quam autem quasi\\nreiciendis et nam sapiente accusantium\"\n" +
                    "  }")
            .contentType("application/json")
            .post()
            .then()
            .log()
            .all()
            .statusCode(500);

//
//    //build request
//    RequestSpecification requestSpecification= RestAssured.given();
//    requestSpecification=requestSpecification.log().all();
//    requestSpecification.baseUri("http://localhost:3000/");
//    requestSpecification.basePath("comments");
//    requestSpecification.body("  {\n" +
//            "    \"postId\": 1,\n" +
//            "    \"id\": 505,\n" +
//            "    \"name\": \"id ankurlabore ex et quam laborum\",\n" +
//            "    \"email\": \"ankurEliseo@gardner.biz\",\n" +
//            "    \"body\": \"ankurlaudantium enim quasi est quidem magnam voluptate ipsam eos\\ntempora quo necessitatibus\\ndolor quam autem quasi\\nreiciendis et nam sapiente accusantium\"\n" +
//            "  }");
//    requestSpecification.contentType("application/json");
//
//    //hit request and get response
//    Response response=requestSpecification.post();
//
//    //validate response
//    ValidatableResponse validatableResponse=response.then();
//    validatableResponse.statusCode(500);

//    System.out.println("now checking for exiting response");
//
//    RequestSpecification requestSpecification1= RestAssured.given();
//    requestSpecification=requestSpecification.log().all();
//    requestSpecification.baseUri("http://localhost:3000/");
//    requestSpecification.basePath("comments");
//    requestSpecification.body("  {\n" +
//            "    \"postId\": 1,\n" +
//            "    \"id\": 505,\n" +
//            "    \"name\": \"id ankurlabore ex et quam laborum\",\n" +
//            "    \"email\": \"ankurEliseo@gardner.biz\",\n" +
//            "    \"body\": \"ankurlaudantium enim quasi est quidem magnam voluptate ipsam eos\\ntempora quo necessitatibus\\ndolor quam autem quasi\\nreiciendis et nam sapiente accusantium\"\n" +
//            "  }");
//    requestSpecification.contentType("application/json");
//
//    //hit request and get response
//    Response response1=requestSpecification.post();
//
//    //validate response
//    ValidatableResponse validatableResponse1=response.then();
//    validatableResponse.statusCode(500);


}
}
